#!bin/sh
#launcher.sh
cd&&cd /home/omegadata/Scales&&sudo python /home/omegadata/Scales/Scales.py